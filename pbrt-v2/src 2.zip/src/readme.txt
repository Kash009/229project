README FILE:
Winnie Lin <winnielin@stanford.edu>
Peng Hui How <phow@stanford.edu>

The source code we added is contained in the shapes folder under "helixclass.h" and "helixclass.cpp",
and the SConscript and api.cpp have to be updated to include this class.
  
A texture-less/material-less adapted version of our final scene is contained in there as well.
 running the example.pbrt scene in pbrt will generate the image,
 and the example script in there also shows how our implementation can be used.